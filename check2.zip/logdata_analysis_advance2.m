%% ���O�f�[�^��̓T���v��
addpath("../../../pllib/");

%% �f�[�^�̓ǂݍ���
% �f�[�^�t�@�C���̃t�H���_(�f�B���N�g��)����ݒ肷��
DirName='../20220721_XF9G/';
% ����pMPU(RH850)�̃f�[�^�n��̃t�@�C������ݒ肷��
RhFileList=[...
'M20220721_142851_ADU_XCP_RH850_remap.mat';
'M20220721_144357_ADU_XCP_RH850_remap.mat';
'M20220721_145857_ADU_XCP_RH850_remap.mat';
'M20220721_151357_ADU_XCP_RH850_remap.mat';
'M20220721_152858_ADU_XCP_RH850_remap.mat';
'M20220721_154358_ADU_XCP_RH850_remap.mat';       
'M20220721_155858_ADU_XCP_RH850_remap.mat'];
% �s���v��pMPU(V2H)�̃f�[�^�n��̃t�@�C������ݒ肷��
V2FileList=[...
'M20220721_142851_ADU_XCP_V2H_remap.mat';
'M20220721_144357_ADU_XCP_V2H_remap.mat';
'M20220721_145857_ADU_XCP_V2H_remap.mat';
'M20220721_151358_ADU_XCP_V2H_remap.mat';
'M20220721_152858_ADU_XCP_V2H_remap.mat';
'M20220721_154358_ADU_XCP_V2H_remap.mat';
'M20220721_155858_ADU_XCP_V2H_remap.mat'];

%��L�t�@�C������A���L�̃f�[�^��ǂݍ���
% RhYawRate : ���[���[�g[rad/s]
% RhVx      : �ԑ̐i�s�������x[m/s]
% RhVy      : �ԑ̍��E�������x[m/s]
% V2MapLat  : �ܓx[deg]
% V2MapLon  : �y�x[deg]
[RhTime, RhYawRate, RhVx, RhVy, V2MapLat, V2MapLon,V2Vel,V2VelX,V2VelY,V2Yawr,V2C0,V2C1,V2C2,V2C3,V2StartX,V2EndX] = LoadDataFiles(DirName, V2FileList, RhFileList);

%% �O�����1:�ܓx�o�x����O����\������
% Figure 1�ɁA�ܓx�o�x�̌��ʂ�\������ 
V2MapLatLon=[V2MapLat,V2MapLon];
LatLon=getChopped(V2MapLatLon,0.5646/20000);
figure(1);
%plot( V2MapLat, V2MapLon, '.-');
plot( V2MapLat, V2MapLon, '.-',...
      LatLon(:,1), LatLon(:,2), '.-'  );
axis equal; % �c���Ɖ����𓯂��ɂ���
%return ;
if(0)
    figure(10);
    geoplot(V2MapLon,V2MapLat);
    for i=1:size(V2MapLat)    
        geobasemap('streets');
        geolimits(V2MapLon(i)+0.1708*[-0.005,+0.005],V2MapLat(i)+0.1708*[-0.005,+0.005]);    
        %geobasemap('satellite');
        %geobasemap colorterrain
        drawnow;
        %pause(0.01);
    end
end

%InitLatLon=LatLon(1,1:2);
LatLon=[V2MapLat,V2MapLon];
UtmZone=utmzone(LatLon(1,1),LatLon(1,2));
[Ellipsoid,Estr]=utmgeoid(UtmZone);
utmstruct=defaultm('utm');
utmstruct.zone=UtmZone;
utmstruct.geoid=Ellipsoid;
utmstruct=defaultm(utmstruct);
%[xx,yy]=mfwdtran(utmstruct,LatLon(:,1),LatLon(:,2));
[xx,yy]=projfwd(utmstruct,LatLon(:,1),LatLon(:,2));
xm=xx;
ym=yy;
plot(xm,ym);
axis equal;
%return ;

%% �O�����2:vx,vy,yawrate����O������͂���


for RhV2=0% �ϐ�������������
    % x   : �O���[�o�����ʒu[m]
    % y   : �O���[�o���c�ʒu[m]
    % yaw : �O���[�o���ԑ̊p�x[m]
    %x=0;
    %y=0;
    %yaw=0;
    [cx,cy]=projfwd(utmstruct,LatLon(1,1),LatLon(1,2));    
    [nx,ny]=projfwd(utmstruct,LatLon(10,1),LatLon(10,2)); 
    x  =cx;
    y  =cy;
    yaw=atan2(ny-cy, nx-cx);
    
    % Ts : �T���v�����O���[�g[sec]
    if(RhV2)
        Ts =  10 * 0.001;
    else
        Ts =  0.2;
    end
    
    % ���ׂẴf�[�^����ݒ肷��
    if(RhV2)
        DataSize=size(RhYawRate,1);    
    else
        DataSize=size(V2Yawr,1);
    end
    
    % ���ׂĂ̈ʒu��������������
    % DataSize x 3 �̍s��ŁA��1��x, ��2��y, ��3��yaw

    x_vect_size=11;
    x_y_yaw=zeros(DataSize,3);
    lane_llC0=zeros(DataSize,2);
    lane_lC0=zeros(DataSize,2);
    lane_rC0=zeros(DataSize,2);
    lane_rrC0=zeros(DataSize,2);
    points_l =zeros(DataSize*x_vect_size,2);
    points_r =zeros(DataSize*x_vect_size,2);
    
    % �f�[�^��1����DataSize�܂ŏ�������
    for i=1:DataSize
        if(RhV2)
            vx      = RhVx(i);
            vy      = RhVy(i);
            yawrate = RhYawRate(i);
        else
            vx      = V2VelX(i);
            vy      = V2VelY(i);
            yawrate = V2Yawr(i);
        end
        Sy= sin(yaw);
        Cy= cos(yaw);
        lane_llC0(i,1)=x-Sy*V2C0(i,3);
        lane_llC0(i,2)=y+Cy*V2C0(i,3);
        lane_lC0(i,1) =x-Sy*V2C0(i,1);
        lane_lC0(i,2) =y+Cy*V2C0(i,1);
        lane_rC0(i,1) =x-Sy*V2C0(i,2);
        lane_rC0(i,2) =y+Cy*V2C0(i,2);
        lane_rrC0(i,1)=x-Sy*V2C0(i,4);
        lane_rrC0(i,2)=y+Cy*V2C0(i,4);

        loc_line_l = zeros(x_vect_size,2);
        loc_line_r = zeros(x_vect_size,2);
        x_vect=(0:(x_vect_size-1))'/(x_vect_size-1);
        loc_line_l(:,1)= (V2EndX(i,1)-V2StartX(i,1))*x_vect+V2StartX(i,1);
        loc_line_l(:,2)=V2C0(i,1)+...
                        V2C1(i,1)*loc_line_l(:,1)+...
                        V2C2(i,1)*loc_line_l(:,1).^2+...
                        V2C3(i,1)*loc_line_l(:,1).^3;
        loc_line_r(:,1)= (V2EndX(i,2)-V2StartX(i,2))*x_vect+V2StartX(i,2);
        loc_line_r(:,2)=V2C0(i,2)+...
                        V2C1(i,2)*loc_line_r(:,1)+...
                        V2C2(i,2)*loc_line_r(:,1).^2+...
                        V2C3(i,2)*loc_line_r(:,1).^3;
        R=[Cy,Sy;-Sy,Cy];
        line_l=[x,y]+loc_line_l*R;
        line_r=[x,y]+loc_line_r*R;
        points_vect=((i-1)*x_vect_size+1):(i*x_vect_size);
        points_l(points_vect,:)=line_l;
        points_r(points_vect,:)=line_r;

        [x,y,yaw]=UpdateCarState(vx,vy,yawrate,x,y,yaw,Ts);
        x_y_yaw(i,1)=x;
        x_y_yaw(i,2)=y;
        x_y_yaw(i,3)=yaw;
    end
    
    % Figure 2�ɁA�o�H��ݐς��Čv�Z�������ʂ�\������
    if(RhV2)
        figure(2);
    else
        figure(3);
    end
    plot( xm, ym, '-g',...
           x_y_yaw(:,1), x_y_yaw(:,2),'.-r',...
          lane_lC0(:,1),  lane_lC0(:,2) ,'-c',...
          lane_rC0(:,1),  lane_rC0(:,2) ,'-b');
          %points_l(:,1),points_l(:,2),'.c',...
          %points_r(:,1),points_r(:,2),'.b',...          
          % lane_llC0(:,1), lane_llC0(:,2),'-g',...
          % lane_rrC0(:,1), lane_rrC0(:,2),'-m',...        );
    axis equal;

end

%% ���ԊԊu�𕽋ςɂ����ꍇ�̑Ή��_
if(0)
    xym=[xm,ym];
    xym_size=size(xym,1);
    x_y_yaw_size=size(x_y_yaw,1);
    erritg=0;
    step_l=floor(x_y_yaw_size/xym_size);
    denom=x_y_yaw_size-xym_size*step_l;
    step_h=step_l+1;
    j=1;
    pair=zeros(xym_size,5);
    for i=1:xym_size
        pair(i,1:4)=[xym(i,1),x_y_yaw(j,1),xym(i,2),x_y_yaw(j,2)];
        if(erritg>0)
            erritg=erritg+denom-xym_size;
            step_hl=step_h;
        else
            erritg=erritg+denom;
            step_hl=step_l;
        end    
        pair(i,5)=step_hl;
        j=j+step_hl;
    end
    mean(pair(:,5))
    x_y_yaw_size/xym_size
    figure(4);
    plot( pair(1:100:end,1:2)', pair(1:100:end,3:4)','.-',...
          pair(:,1), pair(:,3),'-',...
          pair(:,2), pair(:,4),'-'     );
    axis equal;
end

%% ���[�����`�F�b�N
if(0)
    l=1;
    r=2;
    DeltaC0=V2C0(:,l)-V2C0(:,r);
    DeltaC1=V2C1(:,l)-V2C1(:,r);
    DeltaC2=V2C2(:,l)-V2C2(:,r);
    DeltaC3=V2C3(:,l)-V2C3(:,r);
    figure(1);
    subplot(2,2,1);
    plot(DeltaC0);
    subplot(2,2,2);
    plot(DeltaC1);
    subplot(2,2,3);
    plot(DeltaC2);
    subplot(2,2,4);
    plot(DeltaC3);
    vect_x=min(V2EndX(:,l), V2EndX(:,r)); 
    width=...%DeltaC0 + ...
          DeltaC1.*vect_x    + ...
          DeltaC2.*vect_x.^2 + ...
          DeltaC3.*vect_x.^3;
    figure(4);
    plot(width);
    figure(5);
    histogram(width);
end     

%% %%%%%%%%%%%%%%%%
VxVyYawr=[V2VelX(:,1),V2VelY(:,1),V2Yawr(:,1)] ;
gnssPathXY=[xm,ym];
gnssPath=appendYaw(gnssPathXY);
ioi_range=1;
alpha=1.0;
cmpPath = getCompensatedPath(VxVyYawr(800*0.2:end,:), gnssPath(800*0.01:end,:), Ts, ioi_range, alpha);
figure(5);
plot(cmpPath(:,1),cmpPath(:,2),'.-b',...
     gnssPath(:,1),gnssPath(:,2),'-r' );
axis equal;

return ;

% % Figure 3�ɑ��s�f�[�^���e�������Ƃɕ`�悷��
prev_size=round(5/Ts);
next_size=round(5/Ts);
start_idx=round(6*60/Ts);
%for i=start_idx:round(5/Ts):DataSize
for i=start_idx:5:DataSize
    %prev_i_vect=max(1,i-prev_size):max(1,i-1);
    %next_i_vect=min(DataSize,i):min(DataSize,i+next_size-1);
    prev_i_vect=(i-prev_size):(i-1);
    next_i_vect=i:(i+next_size-1);
    i_vect=(i-prev_size):(i+next_size-1);
    prev_path = x_y_yaw(prev_i_vect,1:2);
    current_pos = x_y_yaw(i,:);
    next_path = x_y_yaw(next_i_vect,1:2);
    lane_ll = lane_llC0(i_vect,1:2);
    lane_l  = lane_lC0(i_vect,1:2);
    lane_r  = lane_rC0(i_vect,1:2);
    lane_rr = lane_rrC0(i_vect,1:2);
    x_vect_size=11;
    loc_line_l = zeros(x_vect_size,2);
    loc_line_r = zeros(x_vect_size,2);
    x_vect=(0:(x_vect_size-1))'/(x_vect_size-1);
    loc_line_l(:,1)= (V2EndX(i,1)-V2StartX(i,1))*x_vect+V2StartX(i,1);
    loc_line_l(:,2)=V2C0(i,1)+...
                    V2C1(i,1)*loc_line_l(:,1)+...
                    V2C2(i,1)*loc_line_l(:,1).^2+...
                    V2C3(i,1)*loc_line_l(:,1).^3;
    loc_line_r(:,1)= (V2EndX(i,2)-V2StartX(i,2))*x_vect+V2StartX(i,2);
    loc_line_r(:,2)=V2C0(i,2)+...
                    V2C1(i,2)*loc_line_r(:,1)+...
                    V2C2(i,2)*loc_line_r(:,1).^2+...
                    V2C3(i,2)*loc_line_r(:,1).^3;
    Cy=cos(current_pos(1,3));
    Sy=sin(current_pos(1,3));
    R=[Cy,Sy;-Sy,Cy];
    line_l=current_pos(1,1:2)+loc_line_l*R;
    line_r=current_pos(1,1:2)+loc_line_r*R;
        
    if(0)
        figure(6);
        plot( x_y_yaw(:,1), x_y_yaw(:,2),'-b',...
              current_pos(1,1),current_pos(1,2),'*r' );
        axis equal;    
    end
    figure(7);
    plot(prev_path(:,1),prev_path(:,2),'.y',...
         current_pos(1,1),current_pos(1,2),'*r',...
         next_path(:,1),next_path(:,2),'or',...
         lane_ll(:,1),lane_ll(:,2),'.m',...
         lane_l(:,1),lane_l(:,2),'-m',...
         lane_r(:,1),lane_r(:,2),'-c',...
         lane_rr(:,1),lane_rr(:,2),'.c',...
         line_l(:,1),line_l(:,2),'-k',...
         line_r(:,1),line_r(:,2),'-k'         );
    axis equal;
    draw_rect_size=50/3.6*5;
    axis ([-draw_rect_size+current_pos(1,1),...
           +draw_rect_size+current_pos(1,1),...
           -draw_rect_size+current_pos(1,2),...
           +draw_rect_size+current_pos(1,2)     ]);
    drawnow;
    %pause(0.1);    
end

%% 



%% -- �ȏ� --

%% ���݂̎Ԃ̈ʒu�E�p������A���̎Ԃ̈ʒu�E�p�����v�Z����
function [next_x,next_y,next_yaw]=UpdateCarState(vx,vy,yawrate,current_x,current_y,current_yaw,Ts)
%UpdateCarState 
%[in]
% vx       : �ԑ̐i�s�������x[m/s]
% vy       : �ԑ̍��E�������x[m/s]
% yawrate  : ���[���[�g[rad/s]
% prev_x   : �O�̃O���[�o���ʒux[m]
% prev_y   : �O�̃O���[�o���ʒuy[m]
% prev_yaw : �O�̃O���[�o���p��yaw[rad]
%[out]
% x   : ���̃O���[�o���ʒux[m]
% y   : ���̃O���[�o���ʒuy[m]
% yaw : ���̃O���[�o���p��yaw[rad]    
    Sy = sin(current_yaw);
    Cy = cos(current_yaw);
    dx = (vx * Cy - vy * Sy )*Ts;
    dy = (vx * Sy + vy * Cy )*Ts;
    next_x   = current_x + dx;
    next_y   = current_y + dy;
    next_yaw = current_yaw + yawrate * Ts;
end

%% �w�肳�ꂽ�A�f�B���N�g���E�t�@�C�����X�g����ǂݍ���
function [RhTime,RhYawRate,RhVx,RhVy,V2MapLat,V2MapLon,V2Vel,V2VelX,V2VelY,V2Yawr,V2C0,V2C1,V2C2,V2C3,V2StartX,V2EndX] = LoadDataFiles(DirName, V2FileList, RhFileList)
%LoadDataFiles
%[in]
% DirName    : �f�[�^�t�@�C���̃t�H���_(�f�B���N�g��)��
% V2FileList : ����pMPU(RH850)�̃f�[�^�n��̃t�@�C�������X�g
% RhFileList : �s���v��pMPU(V2H)�̃f�[�^�n��̃t�@�C�������X�g
%[out]
% RhYawRate : ���[���[�g[rad/s]
% RhVx      : �ԑ̐i�s�������x[m/s]
% RhVy      : �ԑ̍��E�������x[m/s]
% V2MapLat  : �ܓx[deg]
% V2MapLon  : �y�x[deg]
    %����̍s��ɏ�����
    RhTime=[];
    RhYawRate=[];    
    RhVx=[];
    RhVy=[];
    V2MapLon=[];
    V2MapLat=[];    
    V2Vel=[];
    V2VelX=[];
    V2VelY=[];
    V2Yawr=[];
    V2C0=[];
    V2C1=[];
    V2C2=[];
    V2C3=[];
    V2StartX=[];
    V2EndX=[];
    %���X�g�̃T�C�Y����t�@�C�������擾
    ListCnt=size(V2FileList,1);
    %���X�g�̃t�@�C�������Ԃɓǂݍ��݁A�Ȃ���
    for i=1:ListCnt
        RhData=load([DirName,RhFileList(i,:)],'meBusOut_log');
        V2Data=load([DirName,V2FileList(i,:)],'saBusOut_saBusMe_log','saBusOut_saBusFcLane_log','PlannerVarMsg_logMsg_PLTG_log','PlannerVarMsg_logMsg_PLLT_log','MapHandlerMsg_log','LMBusOutMsg_lmSpaceBus_log');
        RhTime   =cat(1,RhVy,RhData.meBusOut_log.meVhclVelX.signals.values);
        RhYawRate=cat(1,RhYawRate,RhData.meBusOut_log.meVhclRateYaw.signals.values);
        RhVx=cat(1,RhVx,RhData.meBusOut_log.meVhclVelX.signals.values);
        RhVy=cat(1,RhVy,RhData.meBusOut_log.meVhclVelX.signals.values);        
        V2MapLon=cat(1,V2MapLon,V2Data.MapHandlerMsg_log.mhLongitude.signals.values);
        V2MapLat=cat(1,V2MapLat,V2Data.MapHandlerMsg_log.mhLatitude.signals.values);
        V2Vel=cat(1,V2Vel,V2Data.PlannerVarMsg_logMsg_PLLT_log.overlapVel.signals.values);
        %V2Yawr=cat(1,V2Yawr,V2Data.PlannerVarMsg_logMsg_PLLT_log.overlapYawr.signals.values);
        V2VelX=cat(1,V2VelX,V2Data.saBusOut_saBusMe_log.meVecVhclVelX.signals.values);
        V2VelY=cat(1,V2VelY,V2Data.saBusOut_saBusMe_log.meVecVhclVelY.signals.values);
        V2Yawr=cat(1,V2Yawr,V2Data.saBusOut_saBusMe_log.meVecVhclRateYaw.signals.values);
        V2C0=cat(1,V2C0,V2Data.saBusOut_saBusFcLane_log.saVecFcRoadC0.signals.values);
        V2C1=cat(1,V2C1,V2Data.saBusOut_saBusFcLane_log.saVecFcRoadC1.signals.values);
        V2C2=cat(1,V2C2,V2Data.saBusOut_saBusFcLane_log.saVecFcRoadC2.signals.values);
        V2C3=cat(1,V2C3,V2Data.saBusOut_saBusFcLane_log.saVecFcRoadC3.signals.values);

        V2StartX=cat(1,V2StartX,V2Data.saBusOut_saBusFcLane_log.saVecFcRoadStartX.signals.values);
        V2EndX  =cat(1,V2EndX  ,V2Data.saBusOut_saBusFcLane_log.saVecFcRoadEndX.signals.values);
    end
end
