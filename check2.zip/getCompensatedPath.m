function cmpPath = getCompensatedPath(VxVyYawr, gnssPath, Ts, ioi_range, alpha)
%GETCOMPENSATEDPATH この関数の概要をここに記述
%   詳細説明をここに記述
    gnssPathSize=size(gnssPath,1);
    VxVyYawrSize=size(VxVyYawr,1);
    cmpPath=size(VxVyYawrSize+1,1);
    x  =gnssPath(1,1);
    y  =gnssPath(1,2);
    yaw=gnssPath(1,3);
    ioi=1;
    for i=1:VxVyYawrSize    
        cmpPath(i,1:3)=[x,y,yaw];
        vx   = VxVyYawr(i,1);
        vy   = VxVyYawr(i,2);
        dyaw = VxVyYawr(i,3);
        dx  = (vx*cos(yaw)-vy*sin(yaw))*Ts;
        dy  = (vx*sin(yaw)+vy*cos(yaw))*Ts;
        x   = x  + dx;
        y   = y  + dy;
        yaw = yaw+ dyaw*Ts;
        
        ioi_begin=max(1           ,ioi-ioi_range);
        ioi_end  =min(gnssPathSize,ioi+ioi_range);
        ioiPath=gnssPath(ioi_begin:ioi_end,1:3);
        [ns,~,delta_ioi]=getNearest(ioiPath,[x,y]);
        ioi = delta_ioi-1+ioi_begin;
        
        x   = x   * alpha + (ns(1,1))*(1-alpha);
        y   = y   * alpha + (ns(1,2))*(1-alpha);
        yaw = yaw * alpha + (ns(1,3))*(1-alpha);
    
    end
    cmpPath(VxVyYawrSize+1,1:3)=[x,y,yaw];
end