
function [op] = appendYaw( p )
    
    % Yawを3列目に追加する
    
    p_size=size(p,1);    
    op=[p,zeros(p_size,1)];
    
    for i=1:p_size
        i_nxt = min(i+1,p_size);
        i_prv = max(i-1,1);
        pn    = p(i_nxt,:)-p(i_prv,:);
        yaw   = atan2(pn(2),pn(1));
        op(i,3) = yaw;        
    end
    
end