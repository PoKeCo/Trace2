% fig = uifigure;
% sld = uislider(fig,'Limits',[-450 +450],'Value',0,'Position',[50 400 400 3]);
% while (1)
%     %sld.Value   
%     sld.Value    
%     drawnow;
% end

function manualStearingWindow
% Create figure window and components

figStr = uifigure('Position',[100 100 350 275]);

figCg = uigauge(figStr,'Position',[100 100 120 120],'Limits',[-450 450]);

figSlide = uislider(figStr,...
    'Position',[100 75 120 3],...      
    'MajorTicksMode','Manual',...
    'MajorTicks',[-450 450],...
    'Limits',[-450 450],...
    'ValueChangingFcn',@(sld,event) updateGauge(sld,event,figCg));
end

% Create ValueChangedFcn callback
function updateGauge(sld,event,cg)
    %event
    %cg.Value = sld.Value;
    cg.Value = event.Value;
    %cg.Value = event.
    %cg.Value = sld.ValueChangingFcn()
end
